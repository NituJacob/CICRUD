<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Insert extends CI_Controller {
// For data insertion	
public function index(){
$this->form_validation->set_rules('firstname','First Name','required|alpha');	
$this->form_validation->set_rules('reg[lastname]', 'Date of birth', 'regex_match[(0[1-9]|1[0-9]|2[0-9]|3(0|1))-(0[1-9]|1[0-2])-\d{4}]');
$this->form_validation->set_rules('emailid','Email id','required|valid_email');
$this->form_validation->set_rules('contactno','Contact Number','required|numeric|exact_length[10]');
$this->form_validation->set_rules('zipcode','zipcode','required');	

if($this->form_validation->run()){
$fname=$this->input->post('firstname');
$birthdate=$this->input->post('birthdate');
$email=$this->input->post('emailid');
$cntno=$this->input->post('contactno');
$adrss=$this->input->post('zipcode');
$this->load->model('Insert_Model');
$this->Insert_Model->insertdata($fname,$birthdate,$email,$cntno,$adrss);
$this->load->view('insert');
} else {
$this->load->view('insert');
}
}

// For data updation
public function updatedetails(){
$this->form_validation->set_rules('firstname','First Name','required|alpha');	
$this->form_validation->set_rules('reg[lastname]', 'Date of birth', 'regex_match[(0[1-9]|1[0-9]|2[0-9]|3(0|1))-(0[1-9]|1[0-2])-\d{4}]');
$this->form_validation->set_rules('emailid','Email id','required|valid_email');
$this->form_validation->set_rules('contactno','Contact Number','required|numeric|exact_length[10]');
$this->form_validation->set_rules('zipcode','zipcode','required');	

if($this->form_validation->run()){
$fname=$this->input->post('firstname');
$birthdate=$this->input->post('birthdate');
$email=$this->input->post('emailid');
$cntno=$this->input->post('contactno');
$adrss=$this->input->post('zipcode');
$usid=$this->input->post('userid');
$this->load->model('Insert_Model');
$this->Insert_Model->updatedetails($fname,$birthdate,$email,$cntno,$adrss,$usid);
} else {
$this->session->set_flashdata('error', 'Somthing went worng. Try again with valid details !!');
		redirect('read');
}
}

}