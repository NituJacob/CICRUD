<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Insert_Model extends CI_Model {
public function insertdata($fname,$birthdate,$email,$cntno,$zipcode){
$data=array(
			'FirstName'=>$fname,
			'birthdate'=>$birthdate,
			'EmailId'=>$email,
			'ContactNumber'=>$cntno,
			'zipcode'=>$zipcode
		);
$sql_query=$this->db->insert('tblusers',$data);
if($sql_query){
$this->session->set_flashdata('success', 'Registration successful');
		redirect('read');
	}
	else{
		$this->session->set_flashdata('error', 'Somthing went worng. Error!!');
		redirect('read');
	}
	}


public function updatedetails($fname,$birthdate,$email,$cntno,$zipcode,$usid){
$data=array(
			'FirstName'=>$fname,
			'birthdate'=>$birthdate,
			'EmailId'=>$email,
			'ContactNumber'=>$cntno,
			'zipcode'=>$zipcode
		);

$sql_query=$this->db->where('id', $usid)
                ->update('tblusers', $data); 
           if($sql_query){
$this->session->set_flashdata('success', 'Record updated successful');
		redirect('read');
	}
	else{
		$this->session->set_flashdata('error', 'Somthing went worng. Error!!');
		redirect('read');
	}

}








}